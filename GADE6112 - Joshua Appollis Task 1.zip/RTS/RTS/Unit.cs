﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    abstract class Unit
    {
        private int xPos;
        private int yPos;
        private int health;
        private int speed;
        private int attack;
        private int atkRange;
        private int team;
        private string symbol;

        #region Constructors
        public Unit()
        {

        }

        public Unit(int xPos, int yPos, int health, int speed, int attack, int atkRange, int team, string symbol)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.atkRange = atkRange;
            this.team = team;
            this.symbol = symbol;
        }
        #endregion

        #region Accessors
        public int XPos
        {
            get { return xPos; }
            set { xPos = value; }
        }

        public int YPos
        {
            get { return yPos; }
            set { yPos = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public int AtkRange
        {
            get { return atkRange; }
            set { atkRange = value; }
        }

        public int Team
        {
            get { return team; }
            set { team = value; }
        }

        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        #endregion

        public virtual void move()
        {

        }

        public virtual void combat()
        {

        }

        public virtual void inRange()
        {

        }

        public virtual void closetUnit()
        {

        }

        public virtual void destroy()
        {

        }

        public virtual string toString()
        {
            string output;
            output = "";
            return output;
        }
    }
}
