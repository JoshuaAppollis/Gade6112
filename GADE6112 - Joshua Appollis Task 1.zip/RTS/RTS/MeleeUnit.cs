﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    class MeleeUnit : Unit
    {
        public MeleeUnit()
        {

        }

        public MeleeUnit(int xPos, int yPos, int health, int speed, int attack, int atkRange, int team, string symbol)
            : base(xPos, yPos, health, speed, attack, atkRange, team, symbol)
        {

        }

        public override void move()
        {

        }

        public override void combat()
        {

        }

        public override void inRange()
        {

        }

        public override void closetUnit()
        {

        }

        public override void destroy()
        {

        }

        public override string toString()
        {
            string output;
            //output = MeleeUnit.xPos;
            return output;
        }
    }
}
