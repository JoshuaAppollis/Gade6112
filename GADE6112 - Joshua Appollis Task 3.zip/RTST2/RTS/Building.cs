﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    abstract class Building
    {
        protected int xPos;
        protected int yPos;
        protected int health;
        protected int team;
        protected string symbol;

        #region Constructors
        public Building()
        {

        }

        public Building(int xPos, int yPos, int health, int team, string symbol)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.team = team;
            this.symbol = symbol;
        }
        #endregion

        #region Accessors
        public int XPos
        {
            get { return xPos; }
            set { xPos = value; }
        }

        public int YPos
        {
            get { return yPos; }
            set { yPos = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Team
        {
            get { return team; }
            set { team = value; }
        }

        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        #endregion

        public virtual void destroy()
        {

        }

        public virtual string toString()
        {
            string output;
            output = "";
            return output;
        }
    }
}
