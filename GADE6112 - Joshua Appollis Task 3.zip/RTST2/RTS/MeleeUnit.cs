﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    class MeleeUnit : Unit
    {
        public MeleeUnit()
        {

        }

        public MeleeUnit(int xPos, int yPos, int health, int speed, int attack, int atkRange, int team, string symbol, string name)
            : base(xPos, yPos, health, speed, attack, atkRange, team, symbol, name)
        {

        }

        public override void move(int x, int y)
        {
            if (XPos >= 0 && XPos < 20)
                XPos = x;
            if (YPos >= 0 && YPos < 20)
                YPos = y;

        }

        public override void combat(Unit enemy)
        {
            if(this.inRange(enemy))
            {
                enemy.Health -= Attack;
            }
        }

        public override bool inRange(Unit enemy)
        {
            if(!this.Team.Equals(enemy.Team))
            {
                if ((Math.Abs(this.XPos - enemy.XPos) <= this.AtkRange) ||
                    (Math.Abs(this.YPos - enemy.YPos) <= this.AtkRange))
                    return true;


            }
        }

        public override void closetUnit()
        {

        }

        public override void destroy()
        {

        }

        public override string toString()
        {
            string output;
            output = "";
            return output;
        }
    }
}
