﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    class Map
    {
        public static int mapSize = 20;

        private int max = 50; // Maximum number of units that may spawn on map
        private string[,] map = new string[mapSize, mapSize];
        private RangedUnit[] ruBlue = new RangedUnit[50];
        private RangedUnit[] ruRed = new RangedUnit[50];
        private MeleeUnit[] muBlue = new MeleeUnit[50];
        private MeleeUnit[] muRed = new MeleeUnit[50];

        #region Initialise Arrays
        public void initialiseRuBlue()
        {
            for (int i = 0; i < max; i++)
                ruBlue[i] = new RangedUnit(0, 0, 100, 1, 10, 3, 1, ">");
        }

        public void initialiseRuRed()
        {
            for (int i = 0; i < max; i++)
                ruRed[i] = new RangedUnit(0, 0, 100, 1, 10, 3, 2, "<");
        }

        public void initialiseMuBlue()
        {
            for (int i = 0; i < max; i++)
                muBlue[i] = new MeleeUnit(0, 0, 100, 1, 30, 1, 1, "B");
        }

        public void initialiseMuRed()
        {
            for (int i = 0; i < max; i++)
                muRed[i] = new MeleeUnit(0, 0, 100, 1, 30, 1, 2, "R");
        }
        #endregion

        public string newMap()
        {
            string newMap = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    map[i, j] = ".";
                }
            }
            fillUnits(); // Method to place random units on the map (In "Other Methods" Region)
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    newMap += map[i, j];
                }
                newMap += "\n";
            }           
            return newMap;
        }
        
        public void moveUnit(int xPos, int yPos, int xMove, int yMove)
        {
            map[xPos + xMove, yPos + yMove] = map[xPos, yPos];
            map[xPos, xPos] = ".";
        }

        public string updatePos()
        {
            string loadMap;
            loadMap = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    loadMap += (map[i, j]);
                }
                loadMap += ("\n");
            }
            return loadMap;
        }

        #region Other Methods
        private void fillUnits()
        {
            initialiseRuBlue();
            initialiseRuRed();
            initialiseMuBlue();
            initialiseMuRed();

            Random rand = new Random();
            int x, y;

            int ruBCount = 0;
            int muBCount = 0;
            int ruRCount = 0;
            int muRCount = 0;

            for (int i = 0; i < rand.Next(15, max); i++)
            {
                x = rand.Next(0, 20);
                y = rand.Next(0, 20);
                string unit;

                switch (rand.Next(0, 4))
                {
                    case 0:
                        ruBlue[ruBCount].XPos = x;
                        ruBlue[ruBCount].YPos = y;
                        unit = ruBlue[ruBCount].Symbol;
                        ruBCount++;
                        break;

                    case 1:
                        ruRed[ruRCount].XPos = x;
                        ruRed[ruRCount].YPos = y;
                        unit = ruRed[ruRCount].Symbol;
                        ruRCount++;
                        break;

                    case 2:
                        muBlue[muBCount].XPos = x;
                        muBlue[muBCount].YPos = y;
                        unit = muBlue[muBCount].Symbol;
                        muBCount++;
                        break;

                    case 3:
                        muRed[muRCount].XPos = x;
                        muRed[muRCount].YPos = y;
                        unit = muRed[muRCount].Symbol;
                        muRCount++;
                        break;

                    default:
                        unit = ".";
                        break;
                }
                map[x, y] = unit;
            }
        }
        #endregion
    }
}
