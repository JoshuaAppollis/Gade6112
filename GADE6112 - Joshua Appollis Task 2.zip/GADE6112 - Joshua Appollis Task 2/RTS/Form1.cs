﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RTS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Map map = new Map();
            lblBattleField.Text = map.newMap();
        } 

        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrTick.Enabled = true;                      
            btnStart.Enabled = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tmrTick.Enabled = false;
            btnStart.Enabled = true;
        }

        public int tick = 0;
        private void tmrTick_Tick(object sender, EventArgs e)
        {
            tick++;
            lblGameTime.Text = tick.ToString();
        }
    }
}
