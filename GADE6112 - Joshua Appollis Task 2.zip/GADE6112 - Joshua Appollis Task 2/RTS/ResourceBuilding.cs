﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    class ResourceBuilding : Building
    {
        public ResourceBuilding()
        {

        }

        public ResourceBuilding(int xPos, int yPos, int health, int team, string symbol)
            : base(xPos, yPos, health, team, symbol)
        {

        }

        public override void destroy()
        {
            base.destroy();
        }

        public override string toString()
        {
            return base.toString();
        }

        public void genResource()
        {

        }
    }
}
