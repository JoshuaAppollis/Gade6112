﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS
{
    class RangedUnit : Unit
    {
        public RangedUnit()
        {

        }

        public RangedUnit(int xPos, int yPos, int health, int speed, int attack, int atkRange, int team, string symbol, string name)
            : base(xPos, yPos, health, speed, attack, atkRange, team, symbol, name)
        {

        }

        public override void move(int x, int y)
        {

        }

        public override void combat(Unit enemy)
        {

        }

        public override void inRange(Unit enemy)
        {

        }

        public override void closetUnit()
        {

        }

        public override void destroy()
        {

        }

        public override string toString()
        {
            return base.toString();
        }
    }
}
